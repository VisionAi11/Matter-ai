import { Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { History, LogOut, User as UserIcon, Coins, Menu, X, Crown } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import logo from "@/assets/logo.png";

export function NavBar() {
  const { user, signOut } = useAuth();
  const router = useRouter();
  const [credits, setCredits] = useState<number | null>(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!user) { setCredits(null); return; }
    let active = true;
    supabase
      .from("profiles")
      .select("credits")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => { if (active && data) setCredits(data.credits as number); });
    return () => { active = false; };
  }, [user]);

  return (
    <header className="sticky top-0 z-40 border-b border-border/40 bg-background/70 backdrop-blur-xl">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4 sm:h-16 sm:px-6">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="relative h-9 w-9 overflow-hidden rounded-xl shadow-lg shadow-violet/40 sm:h-10 sm:w-10">
            <img src={logo} alt="Matter AI" className="h-full w-full object-cover" />
          </div>
          <div className="flex flex-col leading-none">
            <span className="font-display text-base font-semibold tracking-tight text-gradient sm:text-lg">
              Matter AI
            </span>
            <span className="hidden text-[9px] uppercase tracking-[0.18em] text-muted-foreground sm:block">
              Studio · v2
            </span>
          </div>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-2 sm:flex">
          {user ? (
            <>
              <div className="flex items-center gap-1.5 rounded-full border border-border/60 bg-card/40 px-3 py-1.5 text-xs backdrop-blur">
                <Coins className="h-3.5 w-3.5 text-violet" />
                <span className="tabular-nums font-medium">{credits ?? "—"}</span>
                <span className="text-muted-foreground">credits</span>
              </div>
              <Button asChild variant="ghost" size="sm" className="rounded-full">
                <Link to="/pricing">
                  <Crown className="mr-1.5 h-4 w-4" />
                  Plans
                </Link>
              </Button>
              <Button asChild variant="ghost" size="sm" className="rounded-full">
                <Link to="/history">
                  <History className="mr-1.5 h-4 w-4" />
                  History
                </Link>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="rounded-full"
                onClick={async () => { await signOut(); router.navigate({ to: "/" }); }}
              >
                <LogOut className="mr-1.5 h-4 w-4" />
                Sign out
              </Button>
            </>
          ) : (
            <>
              <Button asChild variant="ghost" size="sm" className="rounded-full">
                <Link to="/pricing">
                  <Crown className="mr-1.5 h-4 w-4" />
                  Plans
                </Link>
              </Button>
              <Button asChild size="sm" className="rounded-full bg-violet text-background shadow-lg shadow-violet/30 hover:bg-violet/90">
                <Link to="/login">
                  <UserIcon className="mr-1.5 h-4 w-4" />
                  Sign in
                </Link>
              </Button>
            </>
          )}
        </nav>

        {/* Mobile credits + menu trigger */}
        <div className="flex items-center gap-2 sm:hidden">
          {user && (
            <div className="flex items-center gap-1 rounded-full border border-border/60 bg-card/50 px-2.5 py-1 text-[11px] backdrop-blur">
              <Coins className="h-3 w-3 text-violet" />
              <span className="tabular-nums font-medium">{credits ?? "—"}</span>
            </div>
          )}
          {user ? (
            <button
              onClick={() => setOpen((v) => !v)}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-border/60 bg-card/50 text-foreground/90"
              aria-label="Menu"
            >
              {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          ) : (
            <Button asChild size="sm" className="h-8 rounded-full bg-violet text-background hover:bg-violet/90">
              <Link to="/login">Sign in</Link>
            </Button>
          )}
        </div>
      </div>

      {/* Mobile menu sheet */}
      {open && user && (
        <div className="border-t border-border/40 bg-background/90 backdrop-blur-xl sm:hidden">
          <div className="mx-auto flex max-w-6xl flex-col gap-1 px-4 py-3">
            <Link
              to="/history"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm hover:bg-card/60"
            >
              <History className="h-4 w-4 text-violet" />
              History
            </Link>
            <Link
              to="/pricing"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm hover:bg-card/60"
            >
              <Crown className="h-4 w-4 text-violet" />
              Plans
            </Link>
            <button
              onClick={async () => { setOpen(false); await signOut(); router.navigate({ to: "/" }); }}
              className="flex items-center gap-2 rounded-lg px-3 py-2.5 text-left text-sm hover:bg-card/60"
            >
              <LogOut className="h-4 w-4 text-violet" />
              Sign out
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
