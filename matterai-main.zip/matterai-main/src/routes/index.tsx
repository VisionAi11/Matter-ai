import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, useEffect, useRef, FormEvent } from "react";
import { Sparkles, Wand2, Download, RefreshCw, ImageIcon, ArrowRight, Loader2, Cpu, Gauge, Zap } from "lucide-react";
import logo from "@/assets/logo.png";
import { useServerFn } from "@tanstack/react-start";
import { generateImage } from "@/server/generate.functions";
import { proxyImage } from "@/server/proxy.functions";
import { useAuth } from "@/lib/auth";
import { NavBar } from "@/components/NavBar";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

type ModelId = "matter-1" | "matter-2-pro";
type Quality = "standard" | "hd" | "ultra";

export const Route = createFileRoute("/")({
  component: Studio,
});

const STAGES = [
  { label: "Analyzing prompt", pct: 12 },
  { label: "Searching neural archives", pct: 26 },
  { label: "Synthesizing composition", pct: 44 },
  { label: "Refining details & lighting", pct: 64 },
  { label: "Color grading & sharpening", pct: 80 },
  { label: "Upscaling to 4K", pct: 92 },
  { label: "Finalizing", pct: 99 },
];

// Per-model animation pacing (ms per stage step)
const STAGE_INTERVAL: Record<ModelId, number> = {
  "matter-1": 2500,      // ~17s across 7 stages
  "matter-2-pro": 3800,  // ~26s across 7 stages
};

const MODEL_INFO: Record<ModelId, { label: string; tagline: string }> = {
  "matter-1": {
    label: "Matter 1.0",
    tagline: "Fast · Web-sourced HD · ~15-20s",
  },
  "matter-2-pro": {
    label: "Matter 2.0 Pro",
    tagline: "Ultra-detailed · Best quality · ~20-30s",
  },
};

const SUGGESTIONS = [
  "A red Ferrari F40 in neon Tokyo at night",
  "Aurora borealis over Icelandic mountains",
  "Macro photo of a hummingbird in flight",
  "Cyberpunk samurai standing in rain",
];

function Studio() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const generate = useServerFn(generateImage);
  const proxy = useServerFn(proxyImage);

  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [stageIdx, setStageIdx] = useState(0);
  const [progress, setProgress] = useState(0);
  const [model, setModel] = useState<ModelId>("matter-1");
  const [quality, setQuality] = useState<Quality>("hd");
  const [enhance, setEnhance] = useState(false);
  const [credits, setCredits] = useState<number | null>(null);
  const [result, setResult] = useState<{
    imageUrl: string;
    sourceUrl: string | null;
    sourceTitle: string | null;
    prompt: string;
    offset: number;
    width: number | null;
    height: number | null;
    source: "web" | "ai";
    enhancedPrompt?: string | null;
    model: ModelId;
  } | null>(null);

  const stageTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => () => { if (stageTimer.current) clearInterval(stageTimer.current); }, []);

  // Hydrate prefs from localStorage
  useEffect(() => {
    try {
      const m = localStorage.getItem("imaginai.model");
      const q = localStorage.getItem("imaginai.quality");
      const e = localStorage.getItem("imaginai.enhance");
      if (m === "matter-1" || m === "matter-2-pro") setModel(m);
      if (q === "standard" || q === "hd" || q === "ultra") setQuality(q);
      if (e === "true") setEnhance(true);
    } catch { /* noop */ }
  }, []);
  useEffect(() => { try { localStorage.setItem("imaginai.model", model); } catch {} }, [model]);
  useEffect(() => { try { localStorage.setItem("imaginai.quality", quality); } catch {} }, [quality]);
  useEffect(() => { try { localStorage.setItem("imaginai.enhance", String(enhance)); } catch {} }, [enhance]);

  // Fetch user credits
  useEffect(() => {
    if (!user) { setCredits(null); return; }
    let active = true;
    supabase
      .from("profiles")
      .select("credits")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => { if (active && data) setCredits(data.credits as number); });
    return () => { active = false; };
  }, [user]);

  async function run(p: string, offset: number) {
    if (!user) { navigate({ to: "/login" }); return; }
    if (credits !== null && credits < 20) {
      toast.error("Not enough credits. Each image costs 20 credits.");
      return;
    }
    setLoading(true);
    setStageIdx(0);
    setProgress(4);

    const interval = STAGE_INTERVAL[model];
    let i = 0;
    stageTimer.current = setInterval(() => {
      i = Math.min(i + 1, STAGES.length - 1);
      setStageIdx(i);
      setProgress(STAGES[i].pct);
    }, interval);

    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const accessToken = sessionData.session?.access_token;
      const res = await generate({
        data: { prompt: p, offset, accessToken, model, quality, enhance },
      });
      if (typeof res.credits === "number") setCredits(res.credits);
      if (res.error || !res.image) {
        toast.error(res.error ?? "Something went wrong.");
        return;
      }
      setProgress(100);
      await new Promise((r) => setTimeout(r, 280));
      setResult({
        imageUrl: res.image.imageUrl,
        sourceUrl: res.image.sourceUrl,
        sourceTitle: res.image.sourceTitle,
        width: res.image.width,
        height: res.image.height,
        prompt: p,
        offset: res.image.offset,
        source: res.image.source ?? "web",
        enhancedPrompt: res.image.enhancedPrompt ?? null,
        model,
      });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Generation failed.");
    } finally {
      if (stageTimer.current) clearInterval(stageTimer.current);
      setLoading(false);
    }
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const p = prompt.trim();
    if (!p) return;
    run(p, 0);
  }

  async function handleDownload() {
    if (!result) return;
    setDownloading(true);
    const t = toast.loading("Preparing 4K download…");
    try {
      let dataUrl: string;
      if (result.imageUrl.startsWith("data:")) {
        dataUrl = result.imageUrl;
      } else {
        const res = await proxy({ data: { url: result.imageUrl } });
        if (res.error || !res.dataUrl) throw new Error(res.error ?? "Download failed");
        dataUrl = res.dataUrl;
      }
      const a = document.createElement("a");
      a.href = dataUrl;
      const safe = result.prompt.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 50);
      const ext = (dataUrl.match(/^data:image\/([a-zA-Z0-9]+)/)?.[1] ?? "jpg").replace("jpeg", "jpg");
      a.download = `imaginai-${safe}-4k.${ext}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      toast.success("Downloaded in original quality", { id: t });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Download failed", { id: t });
    } finally {
      setDownloading(false);
    }
  }

  const stage = STAGES[stageIdx];
  const resolutionLabel =
    result?.source === "ai"
      ? "AI generated"
      : result?.width && result?.height
        ? `${result.width} × ${result.height}`
        : "HD";

  return (
    <div className="min-h-screen bg-studio">
      <NavBar />

      <main className="mx-auto max-w-4xl px-4 pb-24 pt-8 sm:px-6 sm:pt-14">
        {!result && (
          <div className="text-center">
            <div className="mb-5 inline-flex items-center gap-1.5 rounded-full border border-border/60 bg-card/40 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground backdrop-blur sm:text-xs">
              <Sparkles className="h-3 w-3 text-violet" />
              Neural imagination engine
            </div>
            <h1 className="text-balance font-display text-[2.4rem] font-bold leading-[1.05] tracking-tight text-gradient sm:text-6xl md:text-7xl">
              Imagine anything.
              <br />
              See it instantly.
            </h1>
            <p className="mx-auto mt-5 max-w-xl text-balance text-sm leading-relaxed text-muted-foreground sm:text-base">
              Describe the image you want — a car, a landscape, a creature, an abstract scene — and our engine
              crafts it for you in seconds.
            </p>
          </div>
        )}

        <form onSubmit={onSubmit} className="mt-8 sm:mt-12">
          {/* Prompt bar — stacks on mobile, inline on desktop */}
          <div className="group relative rounded-2xl glass-strong p-2 shadow-premium transition focus-within:ring-violet-glow sm:p-2.5">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <div className="flex flex-1 items-center gap-2">
                <div className="pl-2 text-violet/80 sm:pl-3">
                  <Wand2 className="h-5 w-5" />
                </div>
                <input
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="A vintage motorcycle on a mountain road at sunset…"
                  maxLength={300}
                  disabled={loading}
                  className="flex-1 bg-transparent py-2.5 text-[15px] outline-none placeholder:text-muted-foreground/60 sm:py-3 sm:text-base"
                />
              </div>
              <Button
                type="submit"
                disabled={loading || !prompt.trim()}
                className="h-11 w-full gap-1.5 rounded-xl bg-gradient-to-r from-violet to-violet-glow px-6 font-medium text-background shadow-lg shadow-violet/30 transition hover:shadow-violet/50 sm:h-10 sm:w-auto"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Imagining…
                  </>
                ) : (
                  <>
                    Generate
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Controls — full-width grid on mobile, inline on desktop */}
          <div className="mt-3 grid grid-cols-2 gap-2 sm:mt-4 sm:flex sm:flex-wrap sm:items-center sm:justify-center sm:gap-3">
            <div className="col-span-1 flex items-center gap-1.5 rounded-xl border border-border/60 bg-card/40 px-2 py-1 backdrop-blur">
              <img src={logo} alt="" className="ml-1 h-5 w-5 shrink-0 rounded-sm object-cover" />
              <Select value={model} onValueChange={(v) => setModel(v as ModelId)} disabled={loading}>
                <SelectTrigger className="h-9 w-full border-0 bg-transparent text-xs focus:ring-0 sm:h-8 sm:w-[170px]">
                  <SelectValue placeholder="Model">{MODEL_INFO[model].label}</SelectValue>
                </SelectTrigger>
                <SelectContent className="max-w-[280px]">
                  <SelectItem value="matter-1">
                    <div className="flex items-center gap-2 py-0.5">
                      <img src={logo} alt="" className="h-6 w-6 shrink-0 rounded-md object-cover" />
                      <div className="flex flex-col">
                        <span className="font-medium">Matter 1.0</span>
                        <span className="text-[10px] text-muted-foreground">Fast · Web HD · ~15-20s</span>
                      </div>
                    </div>
                  </SelectItem>
                  <SelectItem value="matter-2-pro">
                    <div className="flex items-center gap-2 py-0.5">
                      <img src={logo} alt="" className="h-6 w-6 shrink-0 rounded-md object-cover" />
                      <div className="flex flex-col">
                        <span className="font-medium">Matter 2.0 Pro</span>
                        <span className="text-[10px] text-muted-foreground">Ultra-detailed · Best · ~20-30s</span>
                      </div>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="col-span-1 flex items-center gap-1.5 rounded-xl border border-border/60 bg-card/40 px-2 py-1 backdrop-blur">
              <Gauge className="ml-1 h-3.5 w-3.5 shrink-0 text-violet" />
              <Select value={quality} onValueChange={(v) => setQuality(v as Quality)} disabled={loading}>
                <SelectTrigger className="h-9 w-full border-0 bg-transparent text-xs focus:ring-0 sm:h-8 sm:w-[140px]">
                  <SelectValue placeholder="Quality">{quality === "ultra" ? "Ultra 4K" : quality === "hd" ? "HD" : "Standard"}</SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="standard">Standard</SelectItem>
                  <SelectItem value="hd">HD</SelectItem>
                  <SelectItem value="ultra">Ultra 4K</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <label className={`col-span-2 flex items-center justify-between gap-2 rounded-xl border border-border/60 bg-card/40 px-3 py-2.5 text-xs backdrop-blur transition sm:col-span-1 sm:py-2 ${loading ? "opacity-60" : "cursor-pointer hover:border-violet/60"}`}>
              <span className="flex items-center gap-2">
                <Zap className="h-3.5 w-3.5 text-violet" />
                <span className="font-medium text-foreground/90">Enhance prompt</span>
              </span>
              <Switch checked={enhance} onCheckedChange={setEnhance} disabled={loading} />
            </label>
          </div>

          {/* Tagline + credits */}
          <div className="mt-3 flex flex-wrap items-center justify-center gap-x-2.5 gap-y-1 px-2 text-center text-[11px] text-muted-foreground">
            <span className="font-medium text-foreground/70">{MODEL_INFO[model].tagline}</span>
            <span className="opacity-40">·</span>
            <span>20 credits / image</span>
            {user && credits !== null && (
              <>
                <span className="opacity-40">·</span>
                <span className={credits < 20 ? "font-medium text-destructive" : "font-medium text-violet"}>
                  {credits} credits left
                </span>
              </>
            )}
          </div>

          {!result && !loading && (
            <div className="mt-6 -mx-4 flex gap-2 overflow-x-auto px-4 no-scrollbar sm:mx-0 sm:flex-wrap sm:justify-center sm:overflow-visible sm:px-0">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setPrompt(s)}
                  className="shrink-0 whitespace-nowrap rounded-full border border-border/60 bg-card/40 px-3.5 py-2 text-xs text-muted-foreground backdrop-blur transition hover:border-violet/60 hover:bg-card/60 hover:text-foreground sm:py-1.5"
                >
                  {s}
                </button>
              ))}
            </div>
          )}
        </form>

        {/* Result canvas */}
        <div className="mt-8 sm:mt-12">
          {loading && (
            <div className="overflow-hidden rounded-2xl glass shadow-premium sm:rounded-3xl">
              <div className="relative aspect-square w-full overflow-hidden sm:aspect-[4/3]">
                <div className="absolute inset-0 bg-mesh-anim" />
                <div className="absolute inset-0 scan-beam" />
                <div className="absolute inset-0 opacity-30 bg-grid" />
                <div className="absolute inset-0">
                  {Array.from({ length: 14 }).map((_, i) => (
                    <span
                      key={i}
                      className="particle"
                      style={{
                        left: `${(i * 53) % 100}%`,
                        animationDelay: `${(i * 0.37) % 3}s`,
                        animationDuration: `${4 + (i % 4)}s`,
                      }}
                    />
                  ))}
                </div>

                <div className="absolute inset-0 flex flex-col items-center justify-center gap-5 px-5 text-center">
                  <div className="relative">
                    <div className="absolute inset-0 -m-3 rounded-full bg-violet/30 blur-2xl pulse-glow" />
                    <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl border border-violet/40 bg-background/40 backdrop-blur sm:h-20 sm:w-20">
                      <Sparkles className="h-7 w-7 text-violet animate-spin-slow sm:h-9 sm:w-9" />
                    </div>
                  </div>

                  <div className="w-full max-w-sm space-y-3">
                    <div className="flex items-center justify-between text-xs font-medium tracking-wide text-foreground/80">
                      <span className="flex items-center gap-1.5 truncate">
                        <Loader2 className="h-3 w-3 shrink-0 animate-spin text-violet" />
                        <span className="truncate">{stage.label}…</span>
                      </span>
                      <span className="tabular-nums text-muted-foreground">{progress}%</span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-background/60">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-violet via-violet-glow to-violet transition-all duration-500 ease-out"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground/70">
                      {model === "matter-2-pro" ? "Matter 2.0 Pro" : "Matter 1.0"} · 4K pipeline
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {!loading && result && (
            <div className="fade-in space-y-4">
              <div className="group relative overflow-hidden rounded-2xl border border-border/60 bg-card/40 shadow-premium sm:rounded-3xl">
                <img
                  src={result.imageUrl}
                  alt={result.prompt}
                  className="block h-auto w-full object-cover"
                  loading="eager"
                  onError={() => toast.error("Image failed to load. Try regenerating.")}
                />
                <div className="pointer-events-none absolute right-2.5 top-2.5 flex flex-wrap justify-end gap-1.5 sm:right-3 sm:top-3">
                  {result.model === "matter-2-pro" && (
                    <span className="rounded-full border border-violet/50 bg-violet/25 px-2.5 py-1 text-[10px] font-semibold tracking-wider text-violet backdrop-blur">
                      PRO
                    </span>
                  )}
                  {result.enhancedPrompt && (
                    <span className="rounded-full border border-border/60 bg-background/70 px-2.5 py-1 text-[10px] font-medium tracking-wider text-foreground/90 backdrop-blur">
                      ✨ Enhanced
                    </span>
                  )}
                  <span className="rounded-full border border-border/60 bg-background/70 px-2.5 py-1 text-[10px] font-medium tracking-wider text-foreground/90 backdrop-blur">
                    {resolutionLabel}
                  </span>
                </div>
              </div>

              <div className="rounded-2xl glass p-3 sm:p-4">
                <p className="line-clamp-2 text-sm italic text-muted-foreground sm:text-[15px]">
                  "{result.prompt}"
                </p>
              </div>

              <div className="grid grid-cols-3 gap-2 sm:flex sm:flex-wrap sm:justify-end">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => run(result.prompt, result.offset + 1)}
                  className="h-11 border-border/60 bg-card/40 sm:h-9"
                >
                  <RefreshCw className="h-4 w-4 sm:mr-1.5" />
                  <span className="hidden sm:inline">Regenerate</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleDownload}
                  disabled={downloading}
                  className="h-11 border-border/60 bg-card/40 sm:h-9"
                >
                  {downloading ? (
                    <Loader2 className="h-4 w-4 animate-spin sm:mr-1.5" />
                  ) : (
                    <Download className="h-4 w-4 sm:mr-1.5" />
                  )}
                  <span className="hidden sm:inline">Download 4K</span>
                </Button>
                <Button
                  size="sm"
                  onClick={() => { setResult(null); setPrompt(""); }}
                  className="h-11 bg-gradient-to-r from-violet to-violet-glow text-background shadow-lg shadow-violet/30 hover:shadow-violet/50 sm:h-9"
                >
                  <ImageIcon className="h-4 w-4 sm:mr-1.5" />
                  <span className="hidden sm:inline">New image</span>
                </Button>
              </div>
            </div>
          )}
        </div>

        {!user && !loading && !result && (
          <div className="mt-12 flex justify-center">
            <Link
              to="/login"
              className="rounded-full border border-violet/40 bg-violet/10 px-4 py-2 text-xs text-violet backdrop-blur transition hover:bg-violet/20"
            >
              Sign in to start generating →
            </Link>
          </div>
        )}
      </main>
    </div>
  );
}
