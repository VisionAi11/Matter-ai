import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { NavBar } from "@/components/NavBar";
import { Sparkles, ImageIcon, X, Download, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";

export const Route = createFileRoute("/history")({
  component: HistoryPage,
});

type Gen = {
  id: string;
  prompt: string;
  image_url: string;
  source_url: string | null;
  created_at: string;
};

function HistoryPage() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [items, setItems] = useState<Gen[] | null>(null);
  const [active, setActive] = useState<Gen | null>(null);

  useEffect(() => {
    if (!authLoading && !user) navigate({ to: "/login" });
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("generations")
      .select("id,prompt,image_url,source_url,created_at")
      .order("created_at", { ascending: false })
      .limit(60)
      .then(({ data }) => setItems((data as Gen[]) ?? []));
  }, [user]);

  return (
    <div className="min-h-screen bg-studio">
      <NavBar />
      <main className="mx-auto max-w-6xl px-4 pb-24 pt-10">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-gradient sm:text-4xl">Your gallery</h1>
            <p className="mt-1 text-sm text-muted-foreground">Everything you've imagined, in one place.</p>
          </div>
          <Button asChild className="bg-violet text-background hover:bg-violet/90">
            <Link to="/">
              <Sparkles className="mr-1.5 h-4 w-4" />
              New image
            </Link>
          </Button>
        </div>

        {items === null && (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="aspect-square rounded-2xl border border-border/60 bg-card/40 shimmer" />
            ))}
          </div>
        )}

        {items && items.length === 0 && (
          <div className="rounded-3xl border border-border/60 bg-card/40 p-16 text-center">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-violet/10">
              <ImageIcon className="h-6 w-6 text-violet" />
            </div>
            <h2 className="text-lg font-semibold">No images yet</h2>
            <p className="mt-1 text-sm text-muted-foreground">Generate your first image to start building your gallery.</p>
            <Button asChild className="mt-6 bg-violet text-background hover:bg-violet/90">
              <Link to="/">Start imagining</Link>
            </Button>
          </div>
        )}

        {items && items.length > 0 && (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {items.map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => setActive(g)}
                className="group relative aspect-square overflow-hidden rounded-2xl border border-border/60 bg-card/40 text-left"
              >
                <img
                  src={g.image_url}
                  alt={g.prompt}
                  loading="lazy"
                  className="h-full w-full object-cover transition group-hover:scale-105"
                />
                <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-background/95 via-background/60 to-transparent p-3 opacity-0 transition group-hover:opacity-100">
                  <p className="line-clamp-2 text-xs text-foreground">{g.prompt}</p>
                </div>
              </button>
            ))}
          </div>
        )}

        <Dialog open={!!active} onOpenChange={(o) => !o && setActive(null)}>
          <DialogContent className="max-w-4xl border-border/60 bg-card/95 p-0 overflow-hidden">
            {active && (
              <div className="flex flex-col">
                <div className="relative bg-black/40">
                  <img
                    src={active.image_url}
                    alt={active.prompt}
                    className="max-h-[75vh] w-full object-contain"
                  />
                </div>
                <div className="flex flex-col gap-3 p-5 sm:flex-row sm:items-start sm:justify-between">
                  <p className="text-sm text-foreground/90 sm:max-w-[60%]">{active.prompt}</p>
                  <div className="flex flex-wrap gap-2">
                    <Button asChild variant="outline" size="sm">
                      <a href={active.image_url} download target="_blank" rel="noopener noreferrer">
                        <Download className="mr-1.5 h-4 w-4" />
                        Download
                      </a>
                    </Button>
                    {active.source_url && (
                      <Button asChild variant="ghost" size="sm">
                        <a href={active.source_url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="mr-1.5 h-4 w-4" />
                          Source
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
