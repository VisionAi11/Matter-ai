import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import appCss from "../styles.css?url";
import { AuthProvider } from "@/lib/auth";
import { Toaster } from "@/components/ui/sonner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-studio px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-gradient">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          This canvas doesn't exist.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-violet px-4 py-2 text-sm font-medium text-background transition-colors hover:bg-violet/90"
          >
            Back to studio
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#0b0814" },
      { title: "Matter AI — The World’s Most Realistic AI Image Generator Tr" },
      { name: "description", content: "Matter AI is a next-generation text-to-image platform built to create the most realistic AI-generated visuals ever seen. Designed for creators, designers, film" },
      { name: "author", content: "Matter AI" },
      { property: "og:title", content: "Matter AI — The World’s Most Realistic AI Image Generator Tr" },
      { property: "og:description", content: "Matter AI is a next-generation text-to-image platform built to create the most realistic AI-generated visuals ever seen. Designed for creators, designers, film" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Matter AI — The World’s Most Realistic AI Image Generator Tr" },
      { name: "twitter:description", content: "Matter AI is a next-generation text-to-image platform built to create the most realistic AI-generated visuals ever seen. Designed for creators, designers, film" },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/3733fc4d-4c6a-41dd-8454-26e24043012d/id-preview-68c95d7b--178fd148-c195-4fcf-be78-20cbcf8d7f7a.lovable.app-1777998418942.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/3733fc4d-4c6a-41dd-8454-26e24043012d/id-preview-68c95d7b--178fd148-c195-4fcf-be78-20cbcf8d7f7a.lovable.app-1777998418942.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,400&family=Geist:wght@400;500;600;700&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <AuthProvider>
      <Outlet />
      <Toaster theme="dark" />
    </AuthProvider>
  );
}
