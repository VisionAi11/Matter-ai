import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Check, Sparkles, Crown, KeyRound, Loader2, PartyPopper } from "lucide-react";
import { NavBar } from "@/components/NavBar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/pricing")({
  component: PricingPage,
  head: () => ({
    meta: [
      { title: "Plans & Pricing — Matter AI" },
      { name: "description", content: "Simple plans for Matter AI. Pro users get 100 credits per month to generate stunning images." },
    ],
  }),
});

// Valid Pro activation keys (single-use feel; client-side validation)
const VALID_KEYS = new Set([
  "MATTER-PRO-NOVA-7421",
  "MATTER-PRO-LUNA-3856",
  "MATTER-PRO-ORBIT-9012",
]);

const PLANS = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    tagline: "Try the neural imagination engine",
    credits: "40 credits",
    creditsNote: "one-time on signup",
    icon: Sparkles,
    cta: "Get started",
    href: "/login",
    featured: false,
    features: [
      "Access to Matter 1.0 model",
      "HD image generation",
      "Web-sourced & AI fallback",
      "Personal history",
      "20 credits per image",
    ],
  },
  {
    name: "Pro",
    price: "$9",
    period: "/ month",
    tagline: "For creators who imagine daily",
    credits: "100 credits",
    creditsNote: "every month",
    icon: Crown,
    cta: "Buy now",
    href: "#",
    featured: true,
    features: [
      "Everything in Free",
      "Matter 2.0 Pro — ultra-detailed",
      "Ultra 4K quality unlocked",
      "Prompt enhancement (AI rewriter)",
      "Priority generation queue",
      "100 credits refreshed monthly",
    ],
  },
];

function PricingPage() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [key, setKey] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleBuyNow = () => {
    if (!user) {
      toast.error("Please sign in first to activate Pro.");
      return;
    }
    setKey("");
    setSuccess(false);
    setOpen(true);
  };

  const handleActivate = async () => {
    const k = key.trim().toUpperCase();
    if (!VALID_KEYS.has(k)) {
      toast.error("Invalid activation key. Please check and try again.");
      return;
    }
    setSubmitting(true);
    try {
      // Grant 100 Pro credits
      const { error } = await supabase
        .from("profiles")
        .update({ credits: 100 })
        .eq("user_id", user!.id);
      if (error) throw error;
      try { localStorage.setItem("matter.plan", "pro"); } catch {}
      setSuccess(true);
      toast.success("Welcome to Matter Pro! 100 credits added.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Activation failed.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-studio">
      <NavBar />

      <main className="mx-auto max-w-5xl px-4 pb-24 pt-10 sm:px-6 sm:pt-16">
        <div className="text-center">
          <div className="mb-5 inline-flex items-center gap-1.5 rounded-full border border-border/60 bg-card/40 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground backdrop-blur sm:text-xs">
            <Crown className="h-3 w-3 text-violet" />
            Plans
          </div>
          <h1 className="text-balance font-display text-4xl font-bold leading-[1.05] tracking-tight text-gradient sm:text-6xl">
            Choose your plan
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-balance text-sm leading-relaxed text-muted-foreground sm:text-base">
            Start free. Upgrade when you need more — Pro members get 100 fresh credits every month
            to keep imagining.
          </p>
        </div>

        <div className="mt-12 grid gap-5 sm:mt-16 sm:grid-cols-2 sm:gap-6">
          {PLANS.map((plan) => {
            const Icon = plan.icon;
            return (
              <div
                key={plan.name}
                className={`relative flex flex-col rounded-3xl border p-6 shadow-premium backdrop-blur-xl sm:p-8 ${
                  plan.featured
                    ? "border-violet/60 bg-gradient-to-b from-violet/10 via-card/40 to-card/40"
                    : "border-border/60 bg-card/40"
                }`}
              >
                {plan.featured && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="rounded-full bg-gradient-to-r from-violet to-violet-glow px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-background shadow-lg shadow-violet/40">
                      Most popular
                    </span>
                  </div>
                )}

                <div className="flex items-center gap-3">
                  <div className={`flex h-11 w-11 items-center justify-center rounded-2xl ${plan.featured ? "bg-violet/20 text-violet" : "bg-card/60 text-foreground/80"}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="font-display text-xl font-semibold tracking-tight sm:text-2xl">{plan.name}</h2>
                    <p className="text-xs text-muted-foreground">{plan.tagline}</p>
                  </div>
                </div>

                <div className="mt-6 flex items-end gap-1">
                  <span className="font-display text-4xl font-bold tracking-tight sm:text-5xl">{plan.price}</span>
                  <span className="mb-1.5 text-sm text-muted-foreground">{plan.period}</span>
                </div>

                <div className={`mt-4 rounded-2xl border px-4 py-3 ${plan.featured ? "border-violet/40 bg-violet/5" : "border-border/60 bg-background/30"}`}>
                  <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground">
                    Image credits
                  </div>
                  <div className="mt-1 flex items-baseline gap-1.5">
                    <span className={`font-display text-2xl font-bold ${plan.featured ? "text-violet" : "text-foreground"}`}>
                      {plan.credits}
                    </span>
                    <span className="text-xs text-muted-foreground">{plan.creditsNote}</span>
                  </div>
                </div>

                <ul className="mt-6 flex-1 space-y-2.5">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm text-foreground/85">
                      <Check className={`mt-0.5 h-4 w-4 shrink-0 ${plan.featured ? "text-violet" : "text-foreground/60"}`} />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>

                {plan.featured ? (
                  <Button
                    onClick={handleBuyNow}
                    className="mt-7 h-11 w-full rounded-xl font-medium bg-gradient-to-r from-violet to-violet-glow text-background shadow-lg shadow-violet/30 hover:shadow-violet/50"
                  >
                    <Crown className="mr-1.5 h-4 w-4" />
                    {plan.cta}
                  </Button>
                ) : (
                  <Button
                    asChild
                    className="mt-7 h-11 w-full rounded-xl font-medium bg-card/60 text-foreground hover:bg-card"
                  >
                    <Link to={plan.href}>{plan.cta}</Link>
                  </Button>
                )}
              </div>
            );
          })}
        </div>

        <p className="mt-10 text-center text-xs text-muted-foreground">
          Each generation costs 20 credits. Pro credits refresh on your billing date each month.
        </p>
      </main>

      <Dialog open={open} onOpenChange={(o) => { if (!submitting) setOpen(o); }}>
        <DialogContent className="max-w-md overflow-hidden border-violet/40 bg-card/95 p-0">
          {!success ? (
            <div className="p-6">
              <DialogHeader>
                <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-violet/15 text-violet">
                  <KeyRound className="h-5 w-5" />
                </div>
                <DialogTitle className="text-center font-display text-2xl">Activate Matter Pro</DialogTitle>
                <DialogDescription className="text-center">
                  Enter your Pro activation key to unlock 100 monthly credits and Matter 2.0 Pro.
                </DialogDescription>
              </DialogHeader>

              <div className="mt-5 space-y-3">
                <Input
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                  placeholder="MATTER-PRO-XXXX-0000"
                  autoFocus
                  className="h-12 text-center font-mono text-sm tracking-[0.15em] uppercase"
                  onKeyDown={(e) => { if (e.key === "Enter") handleActivate(); }}
                />
                <Button
                  onClick={handleActivate}
                  disabled={submitting || !key.trim()}
                  className="h-11 w-full rounded-xl bg-gradient-to-r from-violet to-violet-glow text-background"
                >
                  {submitting ? (
                    <><Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> Activating…</>
                  ) : (
                    <>Activate Pro</>
                  )}
                </Button>
                <p className="text-center text-[11px] text-muted-foreground">
                  Don't have a key? Contact support to receive one.
                </p>
              </div>
            </div>
          ) : (
            <SuccessAnimation onClose={() => setOpen(false)} />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function SuccessAnimation({ onClose }: { onClose: () => void }) {
  // Simple confetti-style burst using positioned divs
  const confetti = Array.from({ length: 28 });
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-violet/15 via-card to-card p-8 text-center">
      <div className="pointer-events-none absolute inset-0">
        {confetti.map((_, i) => {
          const left = Math.random() * 100;
          const delay = Math.random() * 0.4;
          const duration = 1.2 + Math.random() * 1.2;
          const size = 6 + Math.random() * 6;
          const colors = ["#a78bfa", "#7c3aed", "#22d3ee", "#f472b6", "#fbbf24"];
          const color = colors[i % colors.length];
          return (
            <span
              key={i}
              className="absolute top-0 block rounded-sm"
              style={{
                left: `${left}%`,
                width: size,
                height: size * 0.4,
                background: color,
                animation: `confetti-fall ${duration}s ${delay}s ease-in forwards`,
                transform: `rotate(${Math.random() * 360}deg)`,
              }}
            />
          );
        })}
      </div>

      <div className="relative">
        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-violet to-violet-glow shadow-[0_0_60px_rgba(167,139,250,0.6)] animate-[crown-pop_0.6s_ease-out]">
          <Crown className="h-10 w-10 text-background" />
        </div>
        <div className="absolute inset-0 -z-10 mx-auto h-20 w-20 animate-ping rounded-full bg-violet/40" />

        <h3 className="mt-6 font-display text-3xl font-bold tracking-tight text-gradient animate-fade-in">
          Welcome to Pro!
        </h3>
        <p className="mt-2 text-sm text-muted-foreground animate-fade-in">
          100 credits have been added to your account.
        </p>

        <div className="mt-5 inline-flex items-center gap-1.5 rounded-full border border-violet/40 bg-violet/10 px-3 py-1 text-xs font-medium text-violet animate-fade-in">
          <PartyPopper className="h-3.5 w-3.5" />
          Matter 2.0 Pro & Ultra 4K unlocked
        </div>

        <Button
          onClick={onClose}
          className="mt-7 h-11 w-full rounded-xl bg-gradient-to-r from-violet to-violet-glow text-background"
          asChild
        >
          <Link to="/">Start creating</Link>
        </Button>
      </div>

      <style>{`
        @keyframes confetti-fall {
          0% { transform: translateY(-20px) rotate(0deg); opacity: 1; }
          100% { transform: translateY(420px) rotate(720deg); opacity: 0; }
        }
        @keyframes crown-pop {
          0% { transform: scale(0.4); opacity: 0; }
          60% { transform: scale(1.15); opacity: 1; }
          100% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
