import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({
  url: z.string().url(),
});

export const proxyImage = createServerFn({ method: "POST" })
  .inputValidator((input) => InputSchema.parse(input))
  .handler(async ({ data }) => {
    try {
      const res = await fetch(data.url, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
          Accept: "image/avif,image/webp,image/*,*/*;q=0.8",
        },
      });
      if (!res.ok) {
        return { error: `Fetch failed (${res.status})`, dataUrl: null };
      }
      const contentType = res.headers.get("content-type") ?? "image/jpeg";
      const buf = await res.arrayBuffer();
      const b64 = Buffer.from(buf).toString("base64");
      return { error: null, dataUrl: `data:${contentType};base64,${b64}` };
    } catch (e) {
      return {
        error: e instanceof Error ? e.message : "Proxy failed",
        dataUrl: null,
      };
    }
  });
