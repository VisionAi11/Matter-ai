import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";

const InputSchema = z.object({
  prompt: z.string().trim().min(1).max(300),
  offset: z.number().int().min(0).max(40).default(0),
  accessToken: z.string().optional(),
  forceAi: z.boolean().optional(),
  model: z.enum(["matter-1", "matter-2-pro"]).default("matter-1"),
  quality: z.enum(["standard", "hd", "ultra"]).default("hd"),
  enhance: z.boolean().optional(),
});

type SerpImage = {
  original?: string;
  thumbnail?: string;
  link?: string;
  source?: string;
  title?: string;
  original_width?: number;
  original_height?: number;
};

type ImageResult = {
  imageUrl: string;
  sourceUrl: string | null;
  sourceTitle: string | null;
  width: number | null;
  height: number | null;
  offset: number;
  source: "web" | "ai";
  enhancedPrompt?: string | null;
};

const QUALITY_SUFFIX: Record<string, string> = {
  standard: "high quality, detailed",
  hd: "high resolution, sharp details, photorealistic, 4K",
  ultra: "ultra-detailed, 8K, cinematic lighting, masterpiece, photorealistic",
};

const IMAGE_FETCH_HEADERS = {
  Accept: "image/avif,image/webp,image/*,*/*;q=0.8",
  "User-Agent": "Mozilla/5.0 (compatible; MatterAI/1.0)",
};

async function isUsableImageUrl(url: string): Promise<boolean> {
  try {
    for (const method of ["HEAD", "GET"] as const) {
      const res = await fetch(url, {
        method,
        redirect: "follow",
        headers: IMAGE_FETCH_HEADERS,
      });

      if (!res.ok) continue;

      const contentType = res.headers.get("content-type")?.toLowerCase() ?? "";
      if (contentType.startsWith("image/")) {
        return true;
      }
    }

    return false;
  } catch {
    return false;
  }
}

async function enhancePromptViaAi(prompt: string): Promise<string | null> {
  const LOVABLE_API_KEY = process.env.LOVABLE_API_KEY;
  if (!LOVABLE_API_KEY) return null;
  try {
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content:
              "You are an expert image prompt engineer. Rewrite the user's prompt into a vivid, descriptive image-generation prompt under 80 words. Add concrete visual details (lighting, composition, style, mood, camera) while preserving intent. Return ONLY the rewritten prompt — no preamble, no quotes.",
          },
          { role: "user", content: prompt },
        ],
      }),
    });
    if (!res.ok) {
      console.error("[enhance] gateway error", res.status, await res.text().catch(() => ""));
      return null;
    }
    const json = await res.json();
    const text: string | undefined = json?.choices?.[0]?.message?.content;
    if (!text) {
      console.error("[enhance] empty content", JSON.stringify(json).slice(0, 500));
      return null;
    }
    return text.trim().replace(/^["']|["']$/g, "").slice(0, 1000);
  } catch (e) {
    console.error("[enhance] exception", e);
    return null;
  }
}

async function generateWithAi(
  prompt: string,
  modelId: string,
): Promise<ImageResult | { error: string }> {
  const LOVABLE_API_KEY = process.env.LOVABLE_API_KEY;
  if (!LOVABLE_API_KEY) {
    return { error: "AI image generation is not configured." };
  }
  try {
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: modelId,
        messages: [{ role: "user", content: prompt }],
        modalities: ["image", "text"],
      }),
    });

    if (res.status === 429) return { error: "Too many requests. Please wait a moment." };
    if (res.status === 402) return { error: "AI credits exhausted. Please add credits." };
    if (!res.ok) return { error: `AI generation failed (${res.status}).` };

    const json = await res.json();
    const dataUrl: string | undefined =
      json?.choices?.[0]?.message?.images?.[0]?.image_url?.url;
    if (!dataUrl) return { error: "AI did not return an image. Try a different prompt." };
    return {
      imageUrl: dataUrl,
      sourceUrl: null,
      sourceTitle: "AI generated",
      width: null,
      height: null,
      offset: 0,
      source: "ai",
    };
  } catch (e) {
    return { error: e instanceof Error ? e.message : "AI generation failed." };
  }
}

async function searchWeb(
  prompt: string,
  offset: number,
  quality: "standard" | "hd" | "ultra",
): Promise<ImageResult | null> {
  const SERPAPI_KEY = process.env.SERPAPI_KEY;
  if (!SERPAPI_KEY) return null;
  try {
    const minW = quality === "ultra" ? 1920 : quality === "hd" ? 1280 : 800;
    const minH = quality === "ultra" ? 1080 : quality === "hd" ? 720 : 600;
    const params = new URLSearchParams({
      engine: "google_images",
      q: `${prompt} ${QUALITY_SUFFIX[quality]}`,
      ijn: "0",
      safe: "active",
      tbs: quality === "standard" ? "" : "isz:l",
      api_key: SERPAPI_KEY,
    });
    const res = await fetch(`https://serpapi.com/search.json?${params}`);
    if (!res.ok) return null;
    const json = (await res.json()) as { images_results?: SerpImage[] };
    const results = (json.images_results ?? [])
      .filter(
        (r) =>
          r.original &&
          (r.original_width ?? 0) >= minW &&
          (r.original_height ?? 0) >= minH,
      )
      .sort(
        (a, b) =>
          (b.original_width ?? 0) * (b.original_height ?? 0) -
          (a.original_width ?? 0) * (a.original_height ?? 0),
      );
    if (results.length === 0) return null;

    const startIndex = Math.min(offset, results.length - 1);
    const candidates = results.slice(startIndex, startIndex + 5);

    for (const [candidateOffset, pick] of candidates.entries()) {
      const isUsable = await isUsableImageUrl(pick.original!);
      if (!isUsable) continue;

      return {
        imageUrl: pick.original!,
        sourceUrl: pick.link ?? null,
        sourceTitle: pick.title ?? pick.source ?? null,
        width: pick.original_width ?? null,
        height: pick.original_height ?? null,
        offset: startIndex + candidateOffset,
        source: "web",
      };
    }

    return null;
  } catch {
    return null;
  }
}

export const generateImage = createServerFn({ method: "POST" })
  .inputValidator((input) => InputSchema.parse(input))
  .handler(async ({ data }) => {
    const startedAt = Date.now();
    const minDurationMs = data.model === "matter-2-pro" ? 22000 : 15000;
    const token = data.accessToken;
    const SUPABASE_URL = process.env.SUPABASE_URL!;
    const SUPABASE_PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY!;

    const supabase = token
      ? createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
          global: { headers: { Authorization: `Bearer ${token}` } },
          auth: { persistSession: false, autoRefreshToken: false },
        })
      : null;

    let userId: string | null = null;
    if (supabase) {
      const { data: u } = await supabase.auth.getUser();
      userId = u.user?.id ?? null;
    }

    if (!supabase || !userId) {
      return { error: "Please sign in to generate images.", image: null, credits: null };
    }

    // Deduct 20 credits up-front (atomic). Refund on failure.
    const COST = 20;
    const { data: deductRes, error: deductErr } = await supabase.rpc("deduct_credits", {
      _amount: COST,
    });
    if (deductErr || typeof deductRes !== "number" || deductRes < 0) {
      return {
        error: "Not enough credits. Each image costs 20 credits.",
        image: null,
        credits: null,
      };
    }
    let creditsRemaining: number = deductRes;

    const refund = async () => {
      try {
        await supabase
          .from("profiles")
          .update({ credits: creditsRemaining + COST })
          .eq("user_id", userId);
        creditsRemaining = creditsRemaining + COST;
      } catch { /* noop */ }
    };

    // Optionally enhance the prompt first
    let workingPrompt = data.prompt;
    let enhancedPrompt: string | null = null;
    if (data.enhance) {
      const enh = await enhancePromptViaAi(data.prompt);
      if (enh) {
        enhancedPrompt = enh;
        workingPrompt = enh;
      }
    }

    const aiPrompt = `${workingPrompt}, ${QUALITY_SUFFIX[data.quality]}`;
    const aiModelId =
      data.model === "matter-2-pro"
        ? "google/gemini-3-pro-image-preview"
        : "google/gemini-2.5-flash-image";

    let image: ImageResult | null = null;

    // Both models try web search first. Pro uses stricter quality filter.
    const searchQuality = data.model === "matter-2-pro" ? "ultra" : data.quality;
    if (!data.forceAi) {
      image = await searchWeb(workingPrompt, data.offset, searchQuality);
    }

    // Only fall back to AI generation when no matching web image was found
    if (!image) {
      const aiResult = await generateWithAi(aiPrompt, aiModelId);
      if ("error" in aiResult) {
        await refund();
        return { error: aiResult.error, image: null, credits: creditsRemaining };
      }
      image = aiResult;
    }

    image.enhancedPrompt = enhancedPrompt;

    await supabase.from("generations").insert({
      user_id: userId,
      prompt: data.prompt,
      image_url: image.imageUrl,
      source_url: image.sourceUrl,
      source_title: image.sourceTitle,
      result_offset: image.offset,
    });

    // Enforce minimum generation duration per model
    const elapsed = Date.now() - startedAt;
    if (elapsed < minDurationMs) {
      await new Promise((r) => setTimeout(r, minDurationMs - elapsed));
    }

    return { error: null, image, credits: creditsRemaining };
  });
