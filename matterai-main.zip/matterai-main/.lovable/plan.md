## Add model selector, quality selector, and prompt enhancer

Three new controls under the prompt bar — branded model names hide the underlying providers.

### Controls

1. **Model selector** (2 options):
   - **Matter 1.0** → web search first (SerpAPI), AI fallback uses `google/gemini-2.5-flash-image` (Nano Banana, fast).
   - **Matter 2.0 Pro** → AI generation directly using `google/gemini-3-pro-image-preview` (highest quality, slower). Skips web search entirely.

2. **Quality selector** (3 options):
   - **Standard** — default prompt suffix ("high-quality, detailed").
   - **HD** — adds "high resolution, sharp details, photorealistic, 4K".
   - **Ultra 4K** — adds "ultra-detailed, 8K, cinematic lighting, masterpiece, photorealistic" + sets SerpAPI filter to extra-large only.

3. **Prompt enhancer** (toggle switch):
   - When ON, before generation the user prompt is sent to a small LLM (`google/gemini-3-flash-preview`) via Lovable AI Gateway with a system prompt: "Rewrite this image prompt into a vivid, descriptive image-generation prompt under 80 words. Return only the rewritten prompt, no preamble."
   - The enhanced prompt is then used for search/generation. The original prompt is still shown to the user as the caption.
   - Subtle "✨ Enhanced" pill shown on result when used.

### UI

- Compact row of pill controls below the main prompt input, above the suggestion chips.
- Uses shadcn `Select` for Model + Quality, `Switch` + label for enhancer.
- All controls disabled while loading.
- Persist last-used selections in `localStorage`.

### Technical

- `src/server/generate.functions.ts`:
  - Extend `InputSchema` with `model: "matter-1" | "matter-2-pro"`, `quality: "standard" | "hd" | "ultra"`, `enhance: boolean`.
  - New `enhancePrompt(prompt)` helper calling Lovable AI Gateway chat completions with `google/gemini-3-flash-preview`.
  - `generateWithAi` accepts `modelId` param so Matter 2.0 Pro routes to `google/gemini-3-pro-image-preview`.
  - Quality affects: (a) text suffix appended to prompt, (b) SerpAPI `tbs` (`isz:l` for hd/ultra; min-resolution thresholds bumped for ultra).
  - Matter 2.0 Pro skips `searchWeb` entirely.
  - Save the **final prompt used** in `generations.prompt`, plus add no new columns (keep schema unchanged — out of scope).

- `src/routes/index.tsx`:
  - New state: `model`, `quality`, `enhance`, hydrated from localStorage.
  - Pass them to the server fn.
  - Show "Pro" or "Enhanced" pill on the result card alongside resolution badge.

### Files touched
- `src/server/generate.functions.ts`
- `src/routes/index.tsx`
- (no migrations, no new secrets — uses existing `LOVABLE_API_KEY`)

Ready to build on approval.