
DROP FUNCTION IF EXISTS public.deduct_credits(uuid, integer);

CREATE OR REPLACE FUNCTION public.deduct_credits(_amount integer)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  remaining integer;
  uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN
    RETURN -1;
  END IF;

  UPDATE public.profiles
  SET credits = credits - _amount
  WHERE user_id = uid AND credits >= _amount
  RETURNING credits INTO remaining;

  IF remaining IS NULL THEN
    RETURN -1;
  END IF;
  RETURN remaining;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.deduct_credits(integer) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.deduct_credits(integer) TO authenticated;
